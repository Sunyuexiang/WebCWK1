# news/urls.py 或者项目的 urls.py
from django.urls import path
from . import views

urlpatterns = [
    path('api/login', views.login_view, name='login'),
    path('api/logout', views.logout_view, name='logout'),
    path('api/stories', views.handel_stories),
    path('api/stories/<int:story_key>', views.delete_story_view, name='delete_story'),
    path('api/directory', views.handel_company),
]

