# news/models.py
from django.db import models
from django.contrib.auth.models import User

class Author(models.Model):
    user = models.OneToOneField(User, on_delete=models.CASCADE, related_name='author')

class Story(models.Model):
    CATEGORY_CHOICES = [
        ('pol', 'Politics'),
        ('art', 'Art'),
        ('tech', 'Technology'),
        ('trivia', 'Trivia'),
    ]
    REGION_CHOICES = [
        ('uk', 'United Kingdom'),
        ('eu', 'Europe'),
        ('w', 'World'),
    ]
    headline = models.CharField(max_length=64)
    category = models.CharField(max_length=6, choices=CATEGORY_CHOICES)
    region = models.CharField(max_length=2, choices=REGION_CHOICES)
    author = models.ForeignKey(Author, on_delete=models.CASCADE)
    date = models.DateField(auto_now_add=True)
    details = models.CharField(max_length=128)

class Agency(models.Model):
    name = models.CharField(max_length=255)
    url = models.URLField()
    code = models.CharField(max_length=10, unique=True)