# news/views.py
from django.http import JsonResponse, HttpResponse, Http404
from django.views.decorators.csrf import csrf_exempt
from django.views.decorators.http import require_POST, require_GET
from django.contrib.auth import authenticate, login, logout
from .models import Story, Agency
from django.db.models import Q
import json
import datetime
from django.views.decorators.http import require_http_methods
from django.contrib.auth.decorators import login_required

@csrf_exempt
@require_POST
def login_view(request):
    username = request.POST.get('username')
    password = request.POST.get('password')
    user = authenticate(request, username=username, password=password)
    if user is not None:
        login(request, user)
        return HttpResponse("Welcome, {}!".format(user.username), content_type="text/plain")
    else:
        return HttpResponse("Invalid credentials", status=401, content_type="text/plain")

@csrf_exempt
@require_POST
def logout_view(request):
    logout(request)
    return HttpResponse("You have been logged out successfully.", content_type="text/plain")

@csrf_exempt
def handel_stories(request):
    if request.method == 'POST':
        return post_story_view(request)
    if request.method == 'GET':
        return get_story_view(request)

@csrf_exempt
def post_story_view(request):
    if not request.user.is_authenticated:
        return JsonResponse({'error': 'Authentication required'}, status=403)

    try:
        data = json.loads(request.body)
        story = Story(
            headline=data['headline'],
            category=data['category'],
            region=data['region'],
            details=data['details'],
            author=request.user.author
        )
        story.save()
        return JsonResponse({'message': 'Story posted successfully'}, status=201, content_type="text/plain")
    except json.JSONDecodeError:
        return JsonResponse({'error': 'Invalid JSON'}, status=400, content_type="text/plain")
    except KeyError as e:
        return JsonResponse({'error': 'Missing field: {}'.format(e.args[0])}, status=400, content_type="text/plain")

@csrf_exempt
@require_http_methods(["GET"])
def get_story_view(request):
    story_cat = request.GET.get('story_cat', '*')
    story_region = request.GET.get('story_region', '*')
    story_date = request.GET.get('story_date', '*')
    queries = []
    if story_cat != '*':
        queries.append(Q(category=story_cat))
    if story_region != '*':
        queries.append(Q(region=story_region))
    if story_date != '*':
        try:
            date = datetime.datetime.strptime(story_date, '%Y-%m-%d').date()
            queries.append(Q(date__gte=date))
        except ValueError:
            return JsonResponse({'error': 'Invalid date format. Use YYYY-MM-DD.'}, status=400)

    if queries:
        stories = Story.objects.filter(*queries)
    else:
        stories = Story.objects.all()

    if not stories:
        return JsonResponse({'error': 'No stories found matching the criteria'}, status=404)

    stories_data = [
        {
            "key": str(story.pk),
            "headline": story.headline,
            "story_cat": story.category,
            "story_region": story.region,
            "author": story.author.user.get_username() if story.author else "Unknown",
            "story_date": story.date.strftime('%Y-%m-%d'),
            "story_details": story.details
        } for story in stories
    ]

    return JsonResponse({'stories': stories_data})

@csrf_exempt
@login_required
@require_http_methods(["DELETE"])
def delete_story_view(request, story_key):
    try:
        story = Story.objects.get(pk=story_key, author=request.user.author)
        story.delete()
        return HttpResponse("Story deleted successfully.", status=200)
    except Story.DoesNotExist:
        return JsonResponse({'error': 'Story not found or you do not have permission to delete it.'}, status=404)
    except Exception as e:
        return HttpResponse("An error occurred: {}".format(e), status=503)

@csrf_exempt
def handel_company(request):
    if request.method == 'POST':
        return register_agency(request)
    if request.method == 'GET':
        return list_agencies(request)

@csrf_exempt
def register_agency(request):
    if request.method == "POST":
        try:
            data = json.loads(request.body)
            agency_name = data.get("agency_name")
            url = data.get("url")
            agency_code = data.get("agency_code")

            # 检查是否已存在相同的机构代码
            if Agency.objects.filter(code=agency_code).exists():
                return HttpResponse("Agency code already exists.", status=400)

            agency = Agency(name=agency_name, url=url, code=agency_code)
            agency.save()

            return HttpResponse("Agency registered successfully.", status=201)
        except json.JSONDecodeError:
            return HttpResponse("Invalid JSON format", status=400)
        except KeyError as e:
            return HttpResponse(f"Missing field: {e.args[0]}", status=400)
        except Exception as e:
            return HttpResponse(f"Failed to register agency. Error: {str(e)}", status=503)
    else:
        return HttpResponse("Invalid request method", status=405)

def list_agencies(request):
    agencies = Agency.objects.all()
    agency_list = [
        {
            "agency_name": agency.name,  # 假设模型中有name字段存储机构名
            "url": agency.url,  # 假设模型中有url字段存储机构网站的URL
            "agency_code": agency.code  # 假设模型中有code字段存储机构的唯一代码
        } for agency in agencies
    ]
    return JsonResponse({"agency_list": agency_list})