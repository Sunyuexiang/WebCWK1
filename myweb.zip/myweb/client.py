import requests
import argparse

# 使用 requests 的 Session 对象来维护会话状态
session = requests.Session()
is_logged_in = False  # 初始状态：用户未登录

def login(base_url):
    global is_logged_in  # 声明我们要修改全局变量 is_logged_in
    username = input("Username: ")
    password = input("Password: ")

    url = f"{base_url}/api/login"  # 确保 base_url 是正确的格式
    response = session.post(url, data={"username": username, "password": password})  # 使用 session 发送请求

    if response.status_code == 200:
        print(response.text)  # 显示来自服务器的欢迎消息
        is_logged_in = True  # 更新登录状态
    else:
        print(response.status_code)
        print("Login failed:", response.text)

def logout(base_url):
    global is_logged_in  # 声明我们要修改全局变量 is_logged_in
    url = f"{base_url}/api/logout"  # 确保 base_url 是正确的格式
    response = session.post(url)  # 使用 session 发送请求

    if response.status_code == 200:
        print(response.text)  # 显示告别消息
        is_logged_in = False  # 更新登录状态
    else:
        print(response.status_code)
        print("Logout failed:", response.text)


def post_story(base_url):
    if not is_logged_in:
        print("You must be logged in to post a story.")
        return

    CATEGORY_CHOICES = [
        ('pol', 'Politics'),
        ('art', 'Art'),
        ('tech', 'Technology'),
        ('trivia', 'Trivia'),
    ]
    REGION_CHOICES = [
        ('uk', 'United Kingdom'),
        ('eu', 'Europe'),
        ('w', 'World'),
    ]

    print("Enter story category (choose from below):")
    for choice, name in CATEGORY_CHOICES:
        print(f"{choice}: {name}")
    category = input("Your choice: ")
    while category not in [choice[0] for choice in CATEGORY_CHOICES]:
        print("Invalid category. Please choose a valid option.")
        category = input("Your choice: ")

    print("Enter story region (choose from below):")
    for choice, name in REGION_CHOICES:
        print(f"{choice}: {name}")
    region = input("Your choice: ")
    while region not in [choice[0] for choice in REGION_CHOICES]:
        print("Invalid region. Please choose a valid option.")
        region = input("Your choice: ")

    headline = input("Enter story headline: ")
    details = input("Enter story details: ")

    story_data = {
        "headline": headline,
        "category": category,
        "region": region,
        "details": details
    }

    url = f"{base_url}/api/stories"  # 根据实际 API 调整 URL
    headers = {'Content-Type': 'application/json'}
    response = session.post(url, json=story_data, headers=headers)

    if response.status_code == 201:
        print("Story posted successfully!")
    else:
        print(f"Failed to post story. Status code: {response.status_code}")
        print("Reason:", response.text)


def get_story(base_url):

    params = {
        "story_cat": input("Enter story category (* for any): "),
        "story_region": input("Enter story region (* for any): "),
        "story_date": input("Enter story date (YYYY-MM-DD, * for any): "),
    }

    url = f"{base_url}/api/stories"
    response = session.get(url, params=params)

    if response.status_code == 200:
        stories = response.json().get('stories', [])
        for story in stories:
            print(f"\nKey: {story['key']}\nHeadline: {story['headline']}\nCategory: {story['story_cat']}\nRegion: {story['story_region']}\nAuthor: {story['author']}\nDate: {story['story_date']}\nDetails: {story['story_details']}\n")
    elif response.status_code == 404:
        print("No stories found matching the criteria.")
    else:
        print(f"Failed to get stories. Status code: {response.status_code}, Reason: {response.text}")

def delete_story(base_url):
    if not is_logged_in:
        print("You must be logged in to delete a story.")
        return
    story_key = input("Enter the key of the story you want to delete: ")  # 提示用户输入故事键（key）
    url = f"{base_url}/api/stories/{story_key}"  # 使用故事键构建请求的 URL
    response = session.delete(url)  # 发送 DELETE 请求
    if response.status_code == 200:
        print("Story deleted successfully.")
    else:
        print(f"Failed to delete story. Status code: {response.status_code}, Reason: {response.text}")

def register_agency(base_url):
    agency_name = input("Enter your agency name: ")
    agency_url = input("Enter your agency URL: ")
    agency_code = input("Enter your unique agency code: ")

    data = {
        "agency_name": agency_name,
        "url": agency_url,
        "agency_code": agency_code
    }

    response = requests.post(f"{base_url}/api/directory", json=data)

    if response.status_code == 201:
        print("Agency registered successfully.")
    else:
        print(f"Failed to register agency. Status code: {response.status_code}, Reason: {response.text}")

def list_agencies(directory_url):
    response = requests.get(f"{directory_url}/api/directory")
    if response.status_code == 200:
        agency_list = response.json().get('agency_list', [])
        for agency in agency_list:
            print(f"Name: {agency['agency_name']}, URL: {agency['url']}, Code: {agency['agency_code']}")
    else:
        print(f"Failed to get agency list. Status code: {response.status_code}")

def unregister_instructions():
    print("To unregister your agency from the directory, please contact the directory administrator directly.")
    print("Email: admin@example.com")  # 请替换为实际的管理员联系邮箱

if __name__ == "__main__":
    base_url = input("Enter the URL of the news service (e.g., http://127.0.0.1:8000): ")

    while True:
        if is_logged_in:
            print("\n1. Logout")
            print("2. Post a Story")# 添加发布故事的选项
            print("3. Delete Story")
            print("4. Exit")
            choice = input("Choose an option: ")

            if choice == '1':
                logout(base_url)
            elif choice == '2':  # 处理发布故事的逻辑
                post_story(base_url)
            elif choice == '3':
                delete_story(base_url)
            elif choice == '4':
                break
            else:
                print("Invalid choice. Please enter a valid option.")
        else:
            print("\n1. Login")
            print("2. Get Stories")
            print("3. Register")
            print("4. List Company")
            print("5. Unregister")
            print("6. Exit")
            choice = input("Choose an option: ")

            if choice == '1':
                login(base_url)
            elif choice == '2':
                get_story(base_url)
            elif choice == '3':
                register_agency(base_url)
            elif choice == '4':
                list_agencies(base_url)
            elif choice == '5':
                unregister_instructions()
            elif choice == '6':
                break
            else:
                print("Invalid choice. Please enter a valid option.")


